def some_string():
    return "Hello from a function"

